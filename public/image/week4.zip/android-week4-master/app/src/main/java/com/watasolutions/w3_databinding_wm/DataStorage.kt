package com.watasolutions.w3_databinding_wm

class DataStorage {
    companion object {
        var userData: MutableList<MutableMap<String, String>> = mutableListOf(mutableMapOf(

        ))
        var currentUser:MutableMap<String, String> = mutableMapOf()

    }
}