package com.watasolutions.w3_databinding_wm

class Constants{
    companion object{
        const val KEY_USER = "user"
    }
}